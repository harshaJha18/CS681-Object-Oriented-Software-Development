package edu.umb.cs680.hw12;

public interface DJIAQuoteObserver {
    public void update (DJIAEvent event);
}
