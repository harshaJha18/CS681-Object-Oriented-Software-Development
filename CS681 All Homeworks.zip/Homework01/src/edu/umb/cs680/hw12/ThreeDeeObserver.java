package edu.umb.cs680.hw12;

public class ThreeDeeObserver
    extends SinglecastObserverBase
    implements ObserverEnhanced {
}
