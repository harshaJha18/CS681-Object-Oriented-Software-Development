package edu.umb.cs680.hw12;

class LineChartObserver
    extends SinglecastObserverBase
    implements ObserverEnhanced {

}
