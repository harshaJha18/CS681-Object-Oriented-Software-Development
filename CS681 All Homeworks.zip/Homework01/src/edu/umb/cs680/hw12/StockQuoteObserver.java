package edu.umb.cs680.hw12;

public interface StockQuoteObserver {
    public void update (StockEvent event);
}
