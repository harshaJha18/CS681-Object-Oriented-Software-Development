package edu.umb.cs680.hw11;

public class ThreeDeeObserver
    extends SinglecastObserverBase
    implements MyObserver {
}
