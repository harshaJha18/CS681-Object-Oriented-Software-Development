package edu.umb.cs680.hw11;

public interface DJIAQuoteObserver {
    public void update (DJIAEvent event);
}
