package edu.umb.cs680.hw11;

public interface StockQuoteObserver {
    public void update (StockEvent event);
}
