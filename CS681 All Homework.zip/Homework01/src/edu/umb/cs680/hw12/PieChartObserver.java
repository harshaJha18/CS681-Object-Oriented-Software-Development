package edu.umb.cs680.hw12;

class PieChartObserver extends SinglecastObserverBase {

}
