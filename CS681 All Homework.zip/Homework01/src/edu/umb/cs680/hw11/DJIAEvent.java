package edu.umb.cs680.hw11;

public class DJIAEvent {

    private float quote;

    public DJIAEvent(float quote) {
        this.quote = quote;
    }

    public float getQuote() {
        return quote;
    }
}
