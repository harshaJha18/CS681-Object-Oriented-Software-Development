package edu.umb.cs680.hw11;

class PieChartObserver extends SinglecastObserverBase {

}
