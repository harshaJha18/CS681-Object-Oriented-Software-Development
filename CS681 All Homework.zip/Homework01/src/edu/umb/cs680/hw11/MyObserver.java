package edu.umb.cs680.hw11;

public interface MyObserver {
    public void update(Object event) ;
}
