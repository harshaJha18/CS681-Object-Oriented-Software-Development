package edu.umb.cs680.hw11;

class TableChartObserver
    extends SinglecastObserverBase
    implements MyObserver {

}
