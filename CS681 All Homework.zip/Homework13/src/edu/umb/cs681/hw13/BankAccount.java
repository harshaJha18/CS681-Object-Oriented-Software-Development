package edu.umb.cs681.hw13;

public interface BankAccount {
	public void deposit(double amount);
	public void withdraw(double amount);
}
